<?php

class MemberModel extends MY_Model
{
    protected $table 	= "Member";


}
