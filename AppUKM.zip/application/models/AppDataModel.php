<?php

class AppDataModel extends MY_Model
{
    protected $table 	= "AppData";

}
