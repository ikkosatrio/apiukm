<?php

class ConfigModel extends MY_Model
{
    protected $table 	= "Config";

}
